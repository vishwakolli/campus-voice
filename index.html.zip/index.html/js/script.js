```javascript
// =====================================
// CAMPUS VOICE - JAVASCRIPT
// =====================================

// Set college name
const collegeName = document.getElementById("collegeName");

if (collegeName) {
    collegeName.textContent =
        "Government Engineering College Chamarajanagara Campus Voice";
}

// Current feed
let currentFeed = "trending";

// Feed button IDs
const feedButtons = {
    trending: "trendingButton",
    views: "viewsButton",
    searches: "searchesButton",
    latest: "latestButton"
};

// =====================================
// CHANGE FEED
// =====================================

function changeFeed(type) {
    if (!feedButtons[type]) return;

    currentFeed = type;

    // Highlight the selected feed button
    Object.entries(feedButtons).forEach(([feed, buttonId]) => {
        const button = document.getElementById(buttonId);

        if (!button) return;

        if (feed === currentFeed) {
            button.classList.remove("bg-gray-200", "text-gray-800");
            button.classList.add("bg-blue-600", "text-white");
            button.setAttribute("aria-pressed", "true");
        } else {
            button.classList.remove("bg-blue-600", "text-white");
            button.classList.add("bg-gray-200", "text-gray-800");
            button.setAttribute("aria-pressed", "false");
        }
    });

    filterEvents();
}

// =====================================
// SEARCH AND CATEGORY FILTER
// =====================================

function filterEvents() {
    const searchInput = document.getElementById("searchInput");
    const categoryFilter = document.getElementById("categoryFilter");
    const container = document.getElementById("eventsContainer");
    const noResults = document.getElementById("noResults");

    if (!container) return;

    const searchText = searchInput
        ? searchInput.value.toLowerCase().trim()
        : "";

    const selectedCategory = categoryFilter
        ? categoryFilter.value
        : "all";

    const events = Array.from(
        container.querySelectorAll(".event-card")
    );

    // Filter events
    events.forEach(event => {
        const titleElement = event.querySelector(".event-title");
        const descriptionElement = event.querySelector(".event-description");

        const title = titleElement
            ? titleElement.textContent.toLowerCase()
            : "";

        const description = descriptionElement
            ? descriptionElement.textContent.toLowerCase()
            : "";

        const category = event.getAttribute("data-category") || "";

        const searchMatch =
            title.includes(searchText) ||
            description.includes(searchText);

        const categoryMatch =
            selectedCategory === "all" ||
            category === selectedCategory;

        event.style.display =
            searchMatch && categoryMatch ? "" : "none";
    });

    // Sort events
    events.sort((a, b) => {
        const viewsA = Number(a.getAttribute("data-views")) || 0;
        const viewsB = Number(b.getAttribute("data-views")) || 0;

        const searchesA = Number(a.getAttribute("data-searches")) || 0;
        const searchesB = Number(b.getAttribute("data-searches")) || 0;

        const dateA = new Date(a.getAttribute("data-date") || 0);
        const dateB = new Date(b.getAttribute("data-date") || 0);

        switch (currentFeed) {
            case "views":
                return viewsB - viewsA;

            case "searches":
                return searchesB - searchesA;

            case "latest":
                return dateB - dateA;

            case "trending":
            default:
                const scoreA = viewsA + searchesA * 2;
                const scoreB = viewsB + searchesB * 2;
                return scoreB - scoreA;
        }
    });

    // Reorder cards without removing them
    events.forEach(event => container.appendChild(event));

    // Show or hide the no-results message
    const visibleEvents = events.filter(
        event => event.style.display !== "none"
    );

    if (noResults) {
        noResults.classList.toggle("hidden", visibleEvents.length > 0);
    }
}

// =====================================
// SHOW EVENT DETAILS
// =====================================

function showDetails(eventId) {
    const event = document.getElementById(eventId);

    if (!event) {
        console.error("Event not found:", eventId);
        return;
    }

    // Increase view count
    const views = (Number(event.getAttribute("data-views")) || 0) + 1;
    event.setAttribute("data-views", views);

    const viewCount = event.querySelector(".view-count");

    if (viewCount) {
        viewCount.textContent = views;
    }

    // Get event information
    const title = event.querySelector(".event-title")?.textContent || "Untitled event";
    const description =
        event.querySelector(".event-description")?.textContent || "No description available";

    const detailsContent = document.getElementById("detailsContent");
    const eventDetails = document.getElementById("eventDetails");

    if (!detailsContent || !eventDetails) return;

    // Use textContent to display text safely
    detailsContent.replaceChildren();

    const titleParagraph = document.createElement("p");
    const titleLabel = document.createElement("strong");
    titleLabel.textContent = "Event: ";
    titleParagraph.append(titleLabel, document.createTextNode(title));

    const descriptionParagraph = document.createElement("p");
    const descriptionLabel = document.createElement("strong");
    descriptionLabel.textContent = "Description: ";
    descriptionParagraph.append(
        descriptionLabel,
        document.createTextNode(description)
    );

    const viewsParagraph = document.createElement("p");
    const viewsLabel = document.createElement("strong");
    viewsLabel.textContent = "Views: ";
    viewsParagraph.append(viewsLabel, document.createTextNode(String(views)));

    detailsContent.append(
        titleParagraph,
        descriptionParagraph,
        viewsParagraph
    );

    eventDetails.classList.remove("hidden");

    // Refresh the current sorting order
    filterEvents();
}

// =====================================
// CLOSE EVENT DETAILS
// =====================================

function hideDetails() {
    const eventDetails = document.getElementById("eventDetails");

    if (eventDetails) {
        eventDetails.classList.add("hidden");
    }
}

// =====================================
// INITIALIZE PAGE
// =====================================

document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("searchInput");
    const categoryFilter = document.getElementById("categoryFilter");

    if (searchInput) {
        searchInput.addEventListener("input", filterEvents);
    }

    if (categoryFilter) {
        categoryFilter.addEventListener("change", filterEvents);
    }

    // Display Trending as the default feed
    changeFeed("trending");
});
```
